package com.uhcl.parade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
