package com.uhcl.parade.dto;

public class RegisterDto {

}
