package com.uhcl.parade.dto;

public class ParadePostArticleDto {
	
	
	
	

}
