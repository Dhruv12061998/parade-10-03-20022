package com.uhcl.parade.model;

public enum ParadeRequestStatus {
	
	REQUESTED,ACCEPTED,REJECTED,OTHER

}
